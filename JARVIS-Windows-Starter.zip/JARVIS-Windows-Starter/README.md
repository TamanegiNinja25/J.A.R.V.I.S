# J.A.R.V.I.S. Windows Starter

A starter WPF desktop assistant with:
- Animated sci-fi dashboard
- Text chat
- Optional Windows speech recognition and speech synthesis
- SQLite conversation history
- Local Ollama or cloud OpenAI Responses API backend
- A small, explicit Windows command allowlist
- Basic CPU/RAM/storage telemetry

## Requirements
- Windows 10 22H2 or Windows 11, 64-bit
- .NET 10 SDK
- Visual Studio 2026 with ".NET desktop development", or the .NET CLI
- Microphone for voice input
- Internet and an API key for cloud AI, OR Ollama for local AI

## Build and run
1. Install the .NET 10 SDK: https://dotnet.microsoft.com/download/dotnet/10.0
2. Open PowerShell in the `JARVIS` folder.
3. Run:
   ```powershell
   dotnet restore
   dotnet build -c Release
   dotnet run
   ```

## Configure cloud AI (recommended for this 8 GB RAM PC)
Set your API key in a new PowerShell session:
```powershell
$env:OPENAI_API_KEY = "YOUR_KEY"
$env:JARVIS_PROVIDER = "openai"
$env:JARVIS_MODEL = "gpt-6-astra"
dotnet run
```
For persistent user-level configuration, use `setx OPENAI_API_KEY "YOUR_KEY"` and restart PowerShell. Never commit API keys to source control or package them in the application.

Model availability and API billing depend on the account and current provider offering. Change `JARVIS_MODEL` to a model available to your API project.

## Configure local Ollama
1. Install Ollama for Windows: https://ollama.com/download/windows
2. In PowerShell:
   ```powershell
   ollama pull qwen2.5:1.5b
   $env:JARVIS_PROVIDER = "ollama"
   $env:JARVIS_MODEL = "qwen2.5:1.5b"
   dotnet run
   ```
A 1.5B quantized model is a modest starting point, not a guarantee of good latency on every 8 GB system. Close other memory-heavy applications. Local inference is optional.

## Voice
The Listen button uses the Windows `System.Speech` recognition engine and the default microphone. Available recognition languages and voices depend on Windows speech components installed on the PC. If no British English voice is installed, the app falls back to the default installed voice. The included voice is a functional placeholder, not a movie-accurate voice clone.

## Security boundaries
- The command router only recognizes exact allowlisted phrases.
- It does not execute arbitrary shell commands.
- Do not add unrestricted PowerShell execution as an AI tool.
- Require explicit confirmation for file deletion, administrator operations, account access, purchases, or external communications.
- Keep secrets in environment variables or Windows Credential Manager, never in source files.
- Treat screen contents, websites, documents, and model output as untrusted input.

## Current prototype limitations
This is the first runnable foundation, not the complete JARVIS vision. It does not yet include a custom wake word, continuous background listening, full screen capture/vision, semantic memory retrieval, browser automation, device integrations, or a production installer. Those are subsequent modules in the roadmap.

## Suggested project structure as it grows
- `Core/` orchestration, permissions, task state
- `AI/` cloud and local providers, tool/function calling
- `Voice/` wake word, VAD, STT, TTS
- `Automation/` allowlisted Windows tools and UI Automation
- `Vision/` screen capture, OCR, image understanding
- `Memory/` SQLite, summaries, optional vector retrieval
- `Monitoring/` system telemetry and alerts
- `UI/` holographic WPF interface
- `Integrations/` browser, calendar, smart-home and device adapters
