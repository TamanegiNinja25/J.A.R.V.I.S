# JARVIS implementation roadmap

## Phase 1 — Runnable desktop foundation
- WPF HUD, chat, SQLite history, speech button, local/cloud provider selection
- Basic system telemetry and explicit command allowlist

## Phase 2 — Voice subsystem
- Replace push-to-talk dictation with VAD + whisper.cpp
- Add wake-word detection (openWakeWord) with a visible microphone indicator
- Add configurable TTS provider and voice selection
- Add interruption/cancel support

## Phase 3 — Agent orchestration
- Structured tool/function calling
- Typed tool registry with JSON schemas
- Permission broker and confirmation UI
- Task state machine: plan -> authorize -> execute -> verify -> report
- Audit log for every tool invocation

## Phase 4 — Windows automation
- UI Automation for accessible controls
- App-specific adapters before generic UI interaction
- File operations limited to user-approved folders
- No arbitrary shell execution from model output

## Phase 5 — Vision
- User-initiated screen capture
- OCR and window metadata
- Cloud image understanding only after explicit screen-share consent
- Redact passwords, tokens and sensitive windows

## Phase 6 — Memory
- SQLite profile/preferences and project records
- Conversation summarization
- Retrieval with source and timestamp
- User-visible inspect/edit/delete controls

## Phase 7 — Connectivity
- Browser search and controlled browser automation
- Calendar/email integrations with least-privilege permissions
- Smart-home adapters and local network integrations

## Phase 8 — Production hardening
- Windows Credential Manager
- Signed installer and update channel
- Crash reporting with opt-in
- Unit/integration tests
- Accessibility, privacy controls and resource profiling
- Startup/background service with explicit opt-in
