using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Jarvis;

public sealed class AiService
{
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(90) };
    private readonly string _provider = ReadSetting("JARVIS_PROVIDER", "ollama").ToLowerInvariant();
    private readonly string _model = ReadSetting("JARVIS_MODEL", "qwen2.5:1.5b");
    private readonly string _endpoint = ReadSetting("JARVIS_ENDPOINT", "");
    private readonly string _apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY") ?? "";
    public bool IsConfigured => _provider == "ollama" || !string.IsNullOrWhiteSpace(_apiKey);

    public async Task<string> AskAsync(string prompt, IReadOnlyList<ChatLine> history)
    {
        const string system = """
        You are JARVIS, a precise, courteous, calm, cinematic personal AI assistant.
        Speak naturally with concise British-inspired phrasing. Never claim to have
        performed an action unless a verified tool result confirms it. You cannot
        execute arbitrary commands from conversational text. Ask before sensitive,
        destructive, financial, account, or administrator-level operations.
        """;

        if (_provider == "openai")
            return await AskOpenAiAsync(system, prompt, history);
        return await AskOllamaAsync(system, prompt, history);
    }

    private async Task<string> AskOpenAiAsync(string system, string prompt, IReadOnlyList<ChatLine> history)
    {
        if (string.IsNullOrWhiteSpace(_apiKey))
            throw new InvalidOperationException("OPENAI_API_KEY is not set. Configure it in PowerShell or select Ollama.");
        var input = new List<object> { new { role = "system", content = system } };
        foreach (var line in history.TakeLast(10))
            input.Add(new { role = line.Role, content = line.Content });
        input.Add(new { role = "user", content = prompt });

        var body = JsonSerializer.Serialize(new { model = _model, input });
        using var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/responses");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _apiKey);
        request.Content = new StringContent(body, Encoding.UTF8, "application/json");
        using var response = await _http.SendAsync(request);
        var json = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Cloud AI returned {(int)response.StatusCode}: {json}");
        using var doc = JsonDocument.Parse(json);
        if (doc.RootElement.TryGetProperty("output_text", out var outputText))
            return outputText.GetString() ?? "I received an empty response.";
        var collected = new StringBuilder();
        if (doc.RootElement.TryGetProperty("output", out var output))
            foreach (var item in output.EnumerateArray())
                if (item.TryGetProperty("content", out var content))
                    foreach (var part in content.EnumerateArray())
                        if (part.TryGetProperty("text", out var text))
                            collected.AppendLine(text.GetString());
        return collected.Length > 0 ? collected.ToString().Trim() : "The model returned no text.";
    }

    private async Task<string> AskOllamaAsync(string system, string prompt, IReadOnlyList<ChatLine> history)
    {
        var endpoint = string.IsNullOrWhiteSpace(_endpoint) ? "http://localhost:11434/api/chat" : _endpoint;
        var messages = new List<object> { new { role = "system", content = system } };
        foreach (var line in history.TakeLast(10))
            messages.Add(new { role = line.Role, content = line.Content });
        messages.Add(new { role = "user", content = prompt });
        var body = JsonSerializer.Serialize(new { model = _model, messages, stream = false, options = new { num_ctx = 2048 } });
        using var response = await _http.PostAsync(endpoint, new StringContent(body, Encoding.UTF8, "application/json"));
        var json = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Local AI returned {(int)response.StatusCode}: {json}");
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.GetProperty("message").GetProperty("content").GetString() ?? "I received an empty response.";
    }

    private static string ReadSetting(string name, string fallback) =>
        Environment.GetEnvironmentVariable(name) ?? fallback;
}

public sealed record ChatLine(string Role, string Content);
