namespace Jarvis;
public partial class App : System.Windows.Application { }
