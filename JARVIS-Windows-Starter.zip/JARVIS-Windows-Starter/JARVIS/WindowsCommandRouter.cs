using System.Diagnostics;

namespace Jarvis;

public static class WindowsCommandRouter
{
    // Deliberately narrow allowlist. Never pass model-generated text to cmd.exe or PowerShell.
    public static Task<string?> TryExecuteAsync(string input)
    {
        var text = input.Trim().ToLowerInvariant();
        string? app = text switch
        {
            "open notepad" or "launch notepad" => "notepad.exe",
            "open calculator" or "launch calculator" => "calc.exe",
            "open file explorer" or "open explorer" => "explorer.exe",
            "open task manager" => "taskmgr.exe",
            "open paint" => "mspaint.exe",
            _ => null
        };

        if (app is not null)
        {
            Process.Start(new ProcessStartInfo(app) { UseShellExecute = true });
            return Task.FromResult<string?>($"Certainly. Launching {Path.GetFileNameWithoutExtension(app)}.");
        }

        if (text is "what time is it" or "tell me the time")
            return Task.FromResult<string?>($"The local time is {DateTime.Now:dddd, h:mm tt}.");

        if (text is "what is my system status" or "system status")
            return Task.FromResult<string?>($"JARVIS is running on {Environment.OSVersion}. Device: {Environment.MachineName}. Processor threads available: {Environment.ProcessorCount}. This initial build reports basic host information; detailed telemetry is shown in the dashboard.");

        return Task.FromResult<string?>(null);
    }
}
