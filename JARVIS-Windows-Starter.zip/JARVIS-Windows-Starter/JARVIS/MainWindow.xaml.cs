using System.Diagnostics;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Jarvis;

public partial class MainWindow : Window
{
    private readonly AiService _ai = new();
    private readonly MemoryStore _memory = new();
    private readonly SpeechSynthesizer _speaker = new();
    private SpeechRecognitionEngine? _recognizer;
    private readonly DispatcherTimer _telemetry = new() { Interval = TimeSpan.FromSeconds(2) };
    private readonly PerformanceCounter? _cpu = TryCreateCounter();
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) =>
        {
            var spin = new DoubleAnimation(0, 360, TimeSpan.FromSeconds(18)) { RepeatBehavior = RepeatBehavior.Forever };
            RingRotation.BeginAnimation(RotateTransform.AngleProperty, spin);
            _telemetry.Tick += (_, _) => UpdateTelemetry();
            _telemetry.Start();
            AddMessage("JARVIS", "Good day. Systems are online. I am ready to assist. Configure a cloud or local AI provider in appsettings.json to enable conversational intelligence.");
            await _memory.InitializeAsync();
            UpdateConnectionStatus();
            UpdateTelemetry();
        };
        Closed += (_, _) =>
        {
            _telemetry.Stop();
            _recognizer?.Dispose();
            _speaker.Dispose();
            _cpu?.Dispose();
        };
    }

    private static PerformanceCounter? TryCreateCounter()
    {
        try { return new PerformanceCounter("Processor", "% Processor Time", "_Total"); }
        catch { return null; }
    }

    private void UpdateConnectionStatus()
    {
        var configured = _ai.IsConfigured;
        ConnectionStatus.Text = configured ? "AI CONFIGURED" : "LOCAL COMMANDS ONLY";
        StatusLed.Fill = configured ? Brushes.LimeGreen : Brushes.Goldenrod;
    }

    private void UpdateTelemetry()
    {
        try
        {
            var cpu = _cpu?.NextValue();
            CpuValue.Text = cpu.HasValue ? $"{cpu.Value:0}% utilization" : "Unavailable";
            var ram = new Microsoft.VisualBasic.Devices.ComputerInfo();
            var used = (ram.TotalPhysicalMemory - ram.AvailablePhysicalMemory) / 1024d / 1024 / 1024;
            var total = ram.TotalPhysicalMemory / 1024d / 1024 / 1024;
            RamValue.Text = $"{used:0.0} / {total:0.0} GB";
            var drive = new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory)!);
            DiskValue.Text = $"{drive.AvailableFreeSpace / 1024d / 1024 / 1024:0.0} GB free";
        }
        catch { }
    }

    private async void SendButton_Click(object sender, RoutedEventArgs e) => await SendPromptAsync();
    private async void PromptBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && !Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift))
        {
            e.Handled = true;
            await SendPromptAsync();
        }
    }

    private async Task SendPromptAsync(string? supplied = null)
    {
        if (_busy) return;
        var prompt = (supplied ?? PromptBox.Text).Trim();
        if (prompt.Length == 0) return;
        PromptBox.Clear();
        AddMessage("YOU", prompt);
        await _memory.SaveAsync("user", prompt);

        var commandResult = await WindowsCommandRouter.TryExecuteAsync(prompt);
        if (commandResult is not null)
        {
            AddMessage("JARVIS", commandResult);
            await _memory.SaveAsync("assistant", commandResult);
            Speak(commandResult);
            return;
        }

        _busy = true;
        CoreState.Text = "PROCESSING REQUEST";
        SendButton.IsEnabled = false;
        try
        {
            var history = await _memory.GetRecentAsync(12);
            var answer = await _ai.AskAsync(prompt, history);
            AddMessage("JARVIS", answer);
            await _memory.SaveAsync("assistant", answer);
            Speak(answer);
        }
        catch (Exception ex)
        {
            AddMessage("SYSTEM", $"I encountered an error: {ex.Message}");
        }
        finally
        {
            _busy = false;
            CoreState.Text = "SYSTEM STANDBY";
            SendButton.IsEnabled = true;
        }
    }

    private void AddMessage(string speaker, string message)
    {
        var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
        panel.Children.Add(new TextBlock
        {
            Text = speaker,
            Foreground = speaker == "JARVIS" ? new SolidColorBrush(Color.FromRgb(85, 223, 255)) : Brushes.LightSteelBlue,
            FontSize = 10, FontWeight = FontWeights.Bold
        });
        panel.Children.Add(new TextBlock
        {
            Text = message, Foreground = new SolidColorBrush(Color.FromRgb(225, 244, 252)),
            FontSize = 14, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 3, 0, 0)
        });
        Conversation.Children.Add(panel);
    }

    private void Speak(string text)
    {
        try
        {
            _speaker.SelectVoiceByHints(VoiceGender.Male, VoiceAge.Adult, 0, System.Globalization.CultureInfo.GetCultureInfo("en-GB"));
            _speaker.Rate = -1;
            _speaker.Volume = 90;
            _speaker.SpeakAsync(text);
        }
        catch
        {
            try { _speaker.SpeakAsync(text); } catch { }
        }
    }

    private void ListenButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_recognizer is not null)
            {
                _recognizer.RecognizeAsyncCancel();
                _recognizer.Dispose();
                _recognizer = null;
                ListenButton.Content = "◉ LISTEN";
                CoreState.Text = "SYSTEM STANDBY";
                return;
            }
            _recognizer = new SpeechRecognitionEngine(new System.Globalization.CultureInfo("en-US"));
            _recognizer.LoadGrammar(new DictationGrammar());
            _recognizer.SetInputToDefaultAudioDevice();
            _recognizer.SpeechRecognized += async (_, args) =>
            {
                if (args.Result.Confidence >= 0.65)
                    await Dispatcher.InvokeAsync(() => SendPromptAsync(args.Result.Text));
            };
            _recognizer.RecognizeCompleted += (_, _) => Dispatcher.Invoke(() =>
            {
                ListenButton.Content = "◉ LISTEN";
                CoreState.Text = "SYSTEM STANDBY";
            });
            _recognizer.RecognizeAsync(RecognizeMode.Multiple);
            ListenButton.Content = "■ STOP";
            CoreState.Text = "LISTENING";
        }
        catch (Exception ex)
        {
            AddMessage("SYSTEM", $"Microphone initialization failed: {ex.Message}. Check Windows microphone permissions and installed speech components.");
        }
    }
}
